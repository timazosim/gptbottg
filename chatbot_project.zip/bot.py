from aiogram import Bot
from config import settings

bot = Bot(token=settings.bot_token)
