from aiogram.fsm.state import State, StatesGroup

class ChatStates(StatesGroup):
    chatting = State()
